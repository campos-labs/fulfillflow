"""Read-only audit of evaluated C evidence; writes only a new review directory."""
import hashlib
import json
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from validation.functional.c_evaluated import protocol_hash, sequence, tool_hashes
from validation.functional.c_policy import decision
from validation.functional.c_runtime import verify_export
from validation.functional.c_sources import REFERENCES

BASE=Path('validation/functional').resolve()
OUT=BASE/'.artifacts/c-evaluated-review-01'
RUN=BASE/'results/c-evaluated-01'
PACKAGE=BASE/'.artifacts/c-evaluated-preparation-02'
DOCKER=r'C:\Program Files\Docker\Docker\resources\bin\docker.exe'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def check(value, label):
    if not value: raise ValueError(label)
def docker(*args):
    return subprocess.run([DOCKER,*args],capture_output=True,text=True,check=True,timeout=45).stdout

manifest=read(PACKAGE/'manifest.json')
manifest_hash=digest(PACKAGE/'manifest.json')
check(read(PACKAGE/'release.json')=={'approved':True,'manifest_sha256':manifest_hash},'release')
check(manifest_hash=='77c61cfeda13b8d9ca0074d2caedacaa5feddf0358a8f7ab476b231e965725f2','frozen manifest')
check(manifest['tools']==tool_hashes(),'current tools')
check(manifest['protocol_sha256']==protocol_hash()==digest(PACKAGE/'protocol.md'),'protocol')
for index in ['checksums.sha256','release-checksums.sha256']:
    for line in (PACKAGE/index).read_text().splitlines():
        h,name=line.split('  ',1)
        check(digest((BASE if index=='checksums.sha256' else PACKAGE)/name)==h,name)
for tag,sha in REFERENCES.items():
    check(subprocess.check_output(['git','rev-parse',tag+'^{commit}'],text=True).strip()==sha,'tag '+tag)
    p=BASE/'.artifacts/c-runtimes-01'/tag/'source.json'
    check(digest(p)==manifest['sources'][tag],'source record')
    r=read(p); check(r['sha']==sha,'source SHA');verify_export(r)
check(digest(BASE/'.artifacts/b-closure-01/functional-b-evidence.zip')=='63e6e1a7c3413bdfb95e9d179f72bda973bad08eaf04687c67bab1417ef44295','B preservation')
summary=read(RUN/'summary.json')
check(summary.get('complete') is True and 'error_type' not in summary,'complete')
check([x['case'] for x in summary['cases']]==sequence()==manifest['cases'],'exact sequence')
check({p.name for p in RUN.iterdir() if p.is_dir()}=={x['destination'] for x in sequence()},'destinations')
rows=[];resources=[];counts=Counter();http=Counter();image_ids={};native_hashes=set()
for entry in summary['cases']:
    item=entry['case'];tag=item['version'];action=item['action']
    folder=RUN/item['destination'];case=folder/(tag+'-'+action)
    group=read(folder/'summary.json');r=read(case/'result.json')
    proc=read(folder/(tag+'-'+action+'-supervision.json'))
    detail=read(folder/(tag+'-'+action+'-process.json'))
    check(group['mode']=='evaluated' and 'error' not in group,'group')
    check(group['cases']==[detail] and detail['result']==r,'matching records')
    check(all(detail[k]==v for k,v in proc.items()),'process record')
    classification=decision(case,tag,action,proc)
    check(classification==entry['classification']==detail['classification']==r['status'],'classification')
    check(group['concurrent_container_ids']==[],'concurrent containers')
    check(len(group['resources'])==len(group['cleanup'])==2,'resource count')
    check({x['container_id'] for x in group['resources']}=={x['container_id'] for x in group['cleanup']},'cleanup identities')
    check(all(x['running'] is False and x['exit_code']==0 and x['oom'] is False and 'error_type' not in x for x in group['cleanup']),'container cleanup')
    hashes=read(folder/'tool-hashes.json')
    check(hashes=={k:v for k,v in manifest['tools'].items() if k.endswith('.py')},'per-case tools')
    for name,h in hashes.items(): check(digest(folder/'tool-package'/name)==h,'archived tool')
    check(proc['startup']['pid']==proc['pid'],'native PID')
    check(Path(proc['startup']['prefix'])==Path(proc['interpreter']['prefix'])==BASE/'.artifacts/c-runtimes-01'/tag/'venv','prefix')
    native_hashes.add(proc['interpreter']['native_sha256'])
    calls=r['webhook_calls'];row={**item,'classification':classification,'evidence':case.relative_to(BASE).as_posix(),'http':[c.get('http_status',c.get('transport_error')) for c in calls]}
    for c in calls: http[(tag,str(c.get('http_status',c.get('transport_error'))))]+=1
    if action in ('healthy','control'):
        check(len(calls)==1 and calls[0]['http_status']==(202 if tag=='v1.2.0-rc.1' else 200),'initial HTTP')
    if action in ('duplicate','conflict'):
        check(len(calls)==2 and calls[1]['http_status']==(200 if action=='duplicate' else 409),'reoffer status')
        check((calls[0]['raw_sha256']==calls[1]['raw_sha256'])==(action=='duplicate'),'reoffer bytes')
        check(read(case/'initial-complete.json')==read(case/'after-reoffer.json')==read(case/'final.json'),'reoffer changed state')
    if action in ('control','kill'):
        barrier=read(case/'barrier.json');check(r['barrier_verified'] is True,'barrier')
        target=next(x for x in r['children'] if x['label']==('core-gated-worker' if tag=='v1.2.0-rc.1' else 'core-api'))
        check(barrier['pid']==target['pid'],'transaction PID')
        before=read(case/'outside-barrier.json');core=before['core'];tracking=before.get('tracking',core)
        check(len(tracking['inbox'])==1 and tracking['inbox'][0]['status']=='RECEIVED' and not tracking['timeline'] and not core['notifications'] and not core.get('receipts',[]),'outside pending')
        if action=='kill':
            check(r['kill']['killed'] is True and r['kill']['pid']==barrier['pid'] and r['kill']['exit_code'] is not None,'kill')
            check(read(case/'after-kill.json')==before,'rollback')
            wait=read(case/'without-redelivery.json')
            check(wait['window_seconds']==60 and r['recovery_action']=='explicit_process_restart','observation')
            if tag=='v1.2.0-rc.1':
                check(wait['complete'] is True and len(calls)==1 and calls[0]['http_status']==202,'async recovery')
                check(before['core']['message_inbox'][0]['state']=='PENDING' and not before['core']['message_outbox'],'durable local pending')
                row['recovery']='explicit worker restart; no webhook redelivery'
            else:
                check(wait['complete'] is False and wait['elapsed_seconds']>=60 and len(calls)==2,'sync pending')
                check(calls[1]['action']=='explicit_identical_redelivery' and calls[1]['http_status']==200 and calls[0]['raw_sha256']==calls[1]['raw_sha256'],'explicit recovery')
                row['recovery']='explicit API restart; observed pending for 60 s; one identical redelivery'
            row['rollback_verified']=True
    if action=='unavailable':
        obs=read(case/'request-completion.json');request=calls[0]['request_id']
        row['pending']=[{'owner':owner,'kind':x['kind']} for owner,data in obs.items() for x in data['requests'] if x['request_id']==request and not x['finished']]
        row['restoration_command_seconds']=read(case/'restoration-schedule.json')['actual_seconds_from_offer']
        row['outcome']=r['outcome'];check(len(calls)==1,'no C4 redelivery')
    counts[(tag,action,classification)]+=1
    rows.append(row);resources.extend(group['resources'])
    for x in group['resources']: image_ids.setdefault(x['role'],set()).add(x['image_id'])
check(len(resources)==len({x['container_id'] for x in resources})==len({x['volume'] for x in resources})==108,'resource isolation')
check(all(len(ids)==1 for ids in image_ids.values()) and len(native_hashes)==1,'stable dependencies')
# Current read-only confirmation; do not start historical containers or query their databases.
inspected=json.loads(docker('inspect',*[x['container_id'] for x in resources]))
byid={x['Id']:x for x in inspected}
for r in resources:
    d=byid[r['container_id']];s=d['State'];h=d['HostConfig']
    check(s['Running'] is False and s['ExitCode']==0 and s['OOMKilled'] is False,'current cleanup')
    check(d['Image']==r['image_id'] and h['NanoCpus']==1000000000 and h['Memory']==536870912,'resources')
    owner=d['Config']['Labels']['org.fulfillflow.c.owner'];check(r['volume']==owner+'-'+r['role']+'-data','owner')
    check(any(x.get('Name')==r['volume'] for x in d['Mounts']),'volume mount')
active=docker('ps','--no-trunc','--format','{{.ID}}').splitlines()
report={'status':'review complete','review_utc':datetime.now(timezone.utc).isoformat(),'manifest_sha256':manifest_hash,'protocol_sha256':manifest['protocol_sha256'],'references':REFERENCES,'complete':True,'total':len(rows),'pass':sum(x['classification']=='PASS' for x in rows),'inconclusive':sum(x['classification']=='INCONCLUSIVE' for x in rows),'counts':[{'version':v,'action':a,'classification':c,'count':n} for (v,a,c),n in counts.items()],'cases':rows,'resources':{'unique_containers':len(resources),'all_stopped_exit_zero_no_oom':True,'unique_volumes':108,'active_containers_at_review':active,'images':{k:sorted(v) for k,v in image_ids.items()}},'audit_scope':['All 54 structured classifications rechecked offline','Snapshots, explicit redeliveries, original request correlation, cleanup and tools checked','Frozen sources, release/protocol hashes and B archive checked','Read-only Docker inspection; no new scenario or database restart'],'limitations':['Fixed targeted boundaries, one synthetic event and one carrier; no reliability rate or general superiority estimate','Three rounds are repetitions of the same scenarios, not representative failure sampling','C4 pending at observation limit; terminal fate and root cause unknown; processes stopped after snapshot','C4 precedes durable admission; does not negate post-admission recovery','No link established to historical benchmark HTTP 503','No performance comparison or historical benchmark completion','No independent backup confirmed','Runtime identity checks execute per case; detailed per-case return of capture is not exported; frozen preparation records and checked code remain evidence'],'http_observations':[{'version':v,'outcome':o,'count':n} for (v,o),n in http.items()]}
(OUT/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
files=sorted(p for p in RUN.rglob('*') if p.is_file())
(OUT/'evidence-checksums.sha256').write_text(''.join(digest(p)+'  '+p.relative_to(BASE).as_posix()+'\n' for p in files),encoding='utf-8')
print(json.dumps({'total':report['total'],'pass':report['pass'],'inconclusive':report['inconclusive'],'files_sealed':len(files),'containers_verified':len(inspected),'active_containers':active,'restoration_command_seconds':[x['restoration_command_seconds'] for x in rows if 'restoration_command_seconds' in x]},indent=2))
