# C — conferência do conjunto avaliado 01

Execução encerrada e conferida em 03/10/2026. **54 casos: 45 PASS e nove
INCONCLUSIVE em C4; nenhum FAIL/INVALID registrado pelo coordenador.**
As três rodadas mantiveram a mesma classificação por cenário e versão.
Os códigos individuais 2 de C4 são os desfechos previstos pela política congelada;
não são aprovação da recuperação nem falha de ferramenta ignorada.

| Cenário | v1.0.0 | v1.1.0-rc.1 | v1.2.0-rc.1 |
| --- | --- | --- | --- |
| C5 — conclusão sem intervenção | 3 PASS | 3 PASS | 3 PASS |
| C1 — duplicata após conclusão | 3 PASS | 3 PASS | 3 PASS |
| C2 — mesmo identificador, conteúdo diferente | 3 PASS | 3 PASS | 3 PASS |
| C3 — controle com liberação da barreira | 3 PASS | 3 PASS | 3 PASS |
| C3 — interrupção antes do commit | 3 PASS | 3 PASS | 3 PASS |
| C4 — indisponibilidade antes da oferta | 3 INCONCLUSIVE | 3 INCONCLUSIVE | 3 INCONCLUSIVE |

## Resultados sustentados

C1 manteve os snapshots completos sem efeitos adicionais e retornou 200 na
reoferta idêntica terminal. C2 retornou 409 e manteve os snapshots, sem substituir
o conteúdo original. O código congelado também exige os resultados DUPLICATE e
EVENT_ID_PAYLOAD_CONFLICT; os corpos HTTP não foram exportados integralmente.

Em C3, a barreira identificou o PID que executava a transação-alvo. Após o término
forçado e antes do reinício, o snapshot independente permaneceu igual ao observado
fora da transação: admissão preservada, sem efeitos de negócio parcialmente
confirmados. Os controles liberaram a mesma barreira e concluíram.

Após **reinício explícito**, v1.0 e v1.1 permaneceram pendentes durante 60 s e
concluíram após uma única reentrega dos mesmos bytes. Na v1.2, o trabalho técnico
persistido foi retomado pelo worker reiniciado e concluiu sem reentrega do webhook.
Os nove casos terminaram com uma timeline APPLIED, uma Notification SIMULATED,
Shipment DELIVERED e Order FULFILLED; recibos e estados técnicos pertinentes foram
conferidos. Isso caracteriza a responsabilidade pela retomada na fronteira
exercitada. Não significa reinício automático do processo ou recuperação universal.

Em C4, o comando de restauração começou entre 30,002 e 30,014 s após a oferta.
Esse intervalo identifica o início do comando, não a prontidão do PostgreSQL.
A consulta SQL autenticada posterior foi aprovada nas três versões. Ao fim da
observação prevista após a prontidão, persistia uma requisição correlacionada:
webhook público na v1.0 (cliente ReadTimeout); chamada interna Core na v1.1/v1.2,
apesar do encerramento público com HTTP 503. Os snapshots não tinham admissão,
recibos, timeline, notificações ou mensagens técnicas para o evento. Não houve
reentrega. Os processos foram encerrados após registrar o limite; não sabemos
qual seria o desfecho terminal com observação maior, nem a causa interna da espera.

C4 antecede a admissão durável e não contradiz a recuperação pós-admissão de B/C3.
Os seis HTTP 503 registrados aqui não explicam o 503 da campanha histórica.

## Conferência e preservação

Foram reconferidos os 54 resultados estruturados com a política liberada e com
asserções adicionais sobre os snapshots, identidade do PID interrompido,
reentregas e consistência dos registros. Fontes congeladas, hashes das ferramentas
arquivadas em cada caso, protocolo e liberação coincidem. O ZIP de B mantém seu
hash anterior. Os 108 containers exclusivos estão parados com saída zero, sem OOM
registrado, volumes montados conforme o inventário e identidades preservadas.
Não havia containers concorrentes nos registros dos casos nem ativos na revisão.
Isso não mede a pressão global ou a continuidade energética do host.

O inventário `evidence-checksums.sha256` sela agora os 1.549 arquivos originais do
conjunto. Não é uma assinatura preexistente dos resultados: foi criado nesta
conferência. Nenhum original foi editado. A cópia independente permanece sem
confirmação. Não foram executados novos cenários, restaurações ou consultas aos
bancos históricos. Sem alteração de aplicação, commit ou push nesta análise.

## Limites e encerramento

Protocolo fixado antes deste conjunto, informado pelas qualificações anteriores;
não se trata de avaliação cega. Três rodadas dos mesmos cenários não estimam uma
taxa populacional de confiabilidade. O recorte usa um evento sintético, um carrier,
fronteiras instrumentadas e processos locais; não cobre todas as falhas, escalas,
transições ou concorrência. O mecanismo de instrumentação influencia o tempo;
nenhum tempo aqui deve substituir medição de desempenho.

O retorno detalhado da verificação de runtime é preservado na preparação; durante
cada caso, a verificação é executada e bloqueante, mas seu retorno detalhado não é
exportado novamente. A origem é sustentada pelos inventários, venv/PID registrados,
fontes verificadas e código da ferramenta preservado. Não afirmar inventário
completo de ambiente capturado continuamente.

A etapa de execução avaliada está concluída. Não repetir C4 para buscar aprovação.
Próximo passo: consolidar o fechamento técnico de C e versionar a ferramenta e a
síntese no escopo autorizado; manter resultados brutos em seu destino e sem
incorporá-los às campanhas de desempenho. C4 mantém seu desfecho inconclusivo.

## Registros

- [Resultado completo da conferência](report.json): 54 linhas com cenários e caminhos.
- [Resumo original](../../results/c-evaluated-01/summary.json).
- [Manifesto liberado](../c-evaluated-preparation-02/manifest.json).
- [Protocolo congelado](../c-evaluated-preparation-02/protocol.md).
- [Liberação](../c-evaluated-preparation-02/release.json).
- [Inventário dos originais](evidence-checksums.sha256).
- [Código desta conferência](audit.py): somente leitura das evidências e inspeção Docker.
